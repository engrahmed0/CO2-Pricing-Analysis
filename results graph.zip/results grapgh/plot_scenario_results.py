
import pandas as pd
import matplotlib.pyplot as plt

# Load hourly simulation
df = pd.read_csv("final_hourly_simulation_cost_expected.csv")

# Group and aggregate by CO₂ price
agg = df.groupby("co2_price").agg({
    "total_cost": "sum",
    "co2_emissions": "sum",
    "grid_import": "sum",
    "pv_gen": "sum",
    "battery_discharge": "sum",
    "gas_boiler_heat": "sum",
    "heat_pump_el": "sum",
    "battery_charge": "sum",
    "cost_grid": "sum",
    "co2_cost": "sum",
    "pv_capacity": "mean",
    "battery_capacity": "mean",
    "heat_pump_capacity": "mean"
}).reset_index()

# Total electricity & heat per scenario
agg["total_electricity"] = agg["grid_import"] + agg["pv_gen"] + agg["battery_discharge"]
agg["total_heat"] = agg["gas_boiler_heat"] + agg["heat_pump_el"]

# Plot 1: Total Cost
total_cost = df.groupby("co2_price")["total_cost"].sum().reset_index()
plt.figure(figsize=(8, 5))
plt.plot(total_cost["co2_price"], total_cost["total_cost"], marker='o', linestyle='-', linewidth=2)
plt.title("Total Cost vs CO₂ Price")
plt.xlabel("CO₂ Price (€/ton)")
plt.ylabel("Total Cost (€)")
plt.grid(True)
plt.tight_layout()
plt.show()

# Plot 2: CO₂ Emissions
plt.figure(figsize=(8, 5))
plt.plot(agg["co2_price"], agg["co2_emissions"], marker='o', color='red')
plt.title("CO₂ Emissions vs CO₂ Price")
plt.xlabel("CO₂ Price (€/ton)")
plt.ylabel("Total CO₂ Emissions (kg)")
plt.grid(True)
plt.show()

# Plot 3: Electricity Supply Breakdown
elec = agg[["co2_price", "grid_import", "pv_gen", "battery_discharge"]].set_index("co2_price")
elec.plot(kind="bar", stacked=True, figsize=(10,6))
plt.title("Corrected Electricity Supply Breakdown by CO₂ Price")
plt.xlabel("CO₂ Price (€/ton)")
plt.ylabel("Electricity Supplied (kWh)")
plt.legend(["Grid Import", "PV Generation", "Battery Discharge"])
plt.grid(True)
plt.xticks(rotation=0)
plt.show()

# Plot 4: Heat Supply Breakdown
heat = agg[["co2_price", "gas_boiler_heat", "heat_pump_el"]].set_index("co2_price")
heat.plot(kind="bar", stacked=True, figsize=(10,6))
plt.title("Corrected Heat Generation by Source and CO₂ Price")
plt.xlabel("CO₂ Price (€/ton)")
plt.ylabel("Heat Supplied (kWh)")
plt.legend(["Gas Boiler", "Heat Pump"])
plt.grid(True)
plt.xticks(rotation=0)
plt.show()

# Plot 5: Renewable Share
renewable_share = (agg["pv_gen"] + agg["battery_discharge"]) / agg["total_electricity"]
plt.figure(figsize=(8, 5))
plt.plot(agg["co2_price"], renewable_share * 100, marker='o')
plt.title("Renewable Share in Electricity Supply")
plt.xlabel("CO₂ Price (€/ton)")
plt.ylabel("Renewables Share (%)")
plt.grid(True)
plt.show()

# Plot 6: Battery Utilization
plt.figure(figsize=(10, 6))
plt.bar(agg["co2_price"] - 5, agg["battery_charge"], width=10, label="Charge")
plt.bar(agg["co2_price"] + 5, agg["battery_discharge"], width=10, label="Discharge")
plt.title("Battery Utilization by CO₂ Price")
plt.xlabel("CO₂ Price (€/ton)")
plt.ylabel("Energy (kWh)")
plt.xticks([0, 50, 100])
plt.legend()
plt.grid(True)
plt.show()

# Plot 7: Technology Capacities
plt.figure(figsize=(10, 6))
plt.plot(agg["co2_price"], agg["pv_capacity"], marker='o', label="PV Capacity (kW)")
plt.plot(agg["co2_price"], agg["battery_capacity"], marker='o', label="Battery Capacity (kWh)")
plt.plot(agg["co2_price"], agg["heat_pump_capacity"], marker='o', label="Heat Pump Capacity (kW)")
plt.title("Optimized Technology Capacities by CO₂ Price")
plt.xlabel("CO₂ Price (€/ton)")
plt.ylabel("Installed Capacity")
plt.legend()
plt.grid(True)
plt.show()
